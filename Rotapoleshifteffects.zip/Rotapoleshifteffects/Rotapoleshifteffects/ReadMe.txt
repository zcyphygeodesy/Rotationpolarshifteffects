全空间大地测量全要素自转极移潮效应算法Fortran代码
https://www.zcyphygeodesy.com/h-nd-56.html

[计算目标]
    给定经纬度大地高和时刻，由IERS地球定向参数EOP，计算地面及地球外部空间计算点高程异常（大地水准面mm）、地面重力（μGal）、扰动重力（μGal）、地倾斜（SW南向/西向mas）、垂线偏差（SW南向/西向mas）、水平位移（EN东向/北向mm）、地面径向（大地高mm）、地面正（常）高（mm）、扰动重力梯度（径向10μE）或水平重力梯度（NW北向/西向10μE）的自转极移效应。
    改善IERS2010自转极移效应算法，实现全空间大地测量全要素自转极移效应统一解析计算。这里的重力位的自转极移效应 = 自转极移的离心力位 + 形变附加位（IERS2010）。

[输出结果]
    大地测量全要素地球自转极移效应tdn(14)。
	tdn(1:14)存放10种大地测量要素自转极移效应：高程异常（大地水准面mm）tdn(1)、地面重力⊙（μGal）tdn(2)、扰动重力（μGal）tdn(3)、地倾斜⊙（SW南向/西向mas）tdn(4) tdn(5)、垂线偏差（SW南向/西向mas）tdn(6) tdn(7)、水平位移⊙（EN东向/北向mm）tdn(8) tdn(9)、地面径向⊙（大地高mm）tdn(10)、地面正（常）高⊙（mm）tdn(11)、扰动重力梯度（径向10μE）tdn(12)和水平重力梯度（NW北向/西向10μE）tdn(13) tdn(14)。
    计算点可以位于地面、低空、卫星、海洋或水下空间，上述标注⊙的要素，当且仅当计算点位与地球固连时有效。
[输入地球物理模型文件]
 （1）IERS地球定向参数EOP产品。IERSEOP_C04格式文件IERSeopc04.dat。
[测试入口程序]
    Rotapoleshifteffects.f90
    输出文件reslt.txt记录：长整型ETideLoad格式时间，相对开始时间的天数（实数），tdn(1:14)
[调用模块]
 （1）大地测量全要素自转极移效应计算模块
    PoleCalc(BLH,m1,m2,tdn,GRS)
    输入：BLH(3)－计算点的纬度、经度（度小数）和大地高（m）
    输入：m1,m2－地球自转极移参数
    输入GRS(6)－gm, ae, j2, omega, 1/f, 缺省值
    返回：tdn(1:14)－全要素地球自转极移效应。
 （2）正常重力场计算模块
    GNormalfd(BLH, NFD, GRS)
    返回NFD(5)－正常重力位，正常重力，正常重力梯度，正常重力线方向，正常梯度方向
 （3）勒让德函数及其导数计算模块
    LegPn_dt2(pn,dp1,dp2,n,t)
    计算勒让德函数Pn(t)及其对ψ的一、二阶导数t=cosψ。
 （4）大地坐标形式变换包
    BLH_RLAT(GRS, BLH, RLAT)；BLH_XYZ(GRS, BLH, XYZ)
	RLAT_BLH(GRS, RLAT, BLH)
 （5）时间系统转换包
    CAL2JD (IY0, IM0, ID0, DJM, J)；JD2CAL(DJ1, DJ2, IY, IM, ID, FD, J)
 （6）其他辅助模块
    PickRecord(str0, kln, rec, nn)；tmcnt(tm, iyr, imo, idy, ihr, imn, sec)
    mjdtotm(mjd0, ltm)；tmtostr(tm, tmstr)

[编译连接]
    Fortran固定格式代码，任何fortran编译器，无需任何外部连接库。
[算法公式]参见ETideLoad4.5参考说明书 (https://www.zcyphygeodesy.com)
    8.6.1大地测量要素自转极移形变效应
    8.3.3勒让德函数及对ψ一、二阶导数

DOS可执行测试程序、地球物理模型和全部测试输入输出数据。
